package IncioPOO;

import java.util.ArrayList;
import java.util.List;

public class Produto {
	private String nome;
	private double preco;
	
	public Produto (String nome, double preco) {this.nome=nome;this.preco=preco;}
	
	List<String> nomeProduto = new ArrayList<String>();
	List<Double> precoProduto = new ArrayList<Double>();
	

}
