package IncioPOO;

import javax.swing.JOptionPane;

import java.util.ArrayList;
import java.util.List;


public class ControlandoEstoque {

	public static void main(String[] args) {
		int op, quantidade; double preco; String nome;
		
		
		List<String> nomeProduto = new ArrayList<String>();
		List<Double> precoProduto = new ArrayList<Double>();
		List<Integer> quantidadeProduto = new ArrayList<Integer>();

		
		do {
			JOptionPane.showMessageDialog(null, "Bem vindo ao estoque do MERCADINHO");
			op = Integer.parseInt(JOptionPane.showInputDialog(null, "Escolha a op��o!\n(1) Para Adicionar produtos"
					+ "\n(2) Para excluir um produto\n(3) Para alterar um produto\n(4) Para visualizar o estoque"
					+ "\n(0) Para encerrar o programa"));
			int op1;
			switch(op){
			case 1:
				do {
				nome=JOptionPane.showInputDialog(null,"Digite o nome do produto:");
				nomeProduto.add(nome);
				preco=Double.parseDouble(JOptionPane.showInputDialog(null,"Digite o pre�o do produto:"));
				precoProduto.add(preco);
				quantidade=Integer.parseInt(JOptionPane.showInputDialog(null,"A quantidade de "+nome));
				quantidadeProduto.add(quantidade);
				op=Integer.parseInt(JOptionPane.showInputDialog(null,"Quer adicionar mais produto?\n(1) n�o\n(2) sim"));}while(op!=1);
				System.out.println( "ESTOQUE!");
				for(int i = 0;i<nomeProduto.size();i++) {
					
					for(i = 0;i<precoProduto.size();i++) {
						
						for( i = 0;i<quantidadeProduto.size();i++) {
							
				System.out.println( "Produto: "+nomeProduto.get(i)+"  R$ "+precoProduto.get(i)+" Quant: "+quantidadeProduto.get(i));
				 
						}
					}
				}				
				break;
			case 2:
				do {
				String remover = JOptionPane.showInputDialog(null,"Qual produto voc� que excluir?: ");
				if (nomeProduto.contains(remover)){
					System.out.println("ESTOQUE ATUALIZADO!");
					for(int i = 0;i<nomeProduto.size();i++) {
						nomeProduto.get(i);
						nomeProduto.remove(remover);
						for(i = 0;i<precoProduto.size();i++) {
							precoProduto.get(i);
							precoProduto.remove(i);
							for( i = 0;i<quantidadeProduto.size();i++) {
								quantidadeProduto.get(i);
								quantidadeProduto.remove(i);
								System.out.println( "Produto "+nomeProduto.get(i)+"  R$ "+precoProduto.get(i)+" Quant: "+quantidadeProduto.get(i));
					 
							}
						}
					}				
				}else {JOptionPane.showMessageDialog(null, "Produto n�o existe!");}
				op=Integer.parseInt(JOptionPane.showInputDialog(null,"Quer remover mais produtos?\n(1) n�o\n(2) sim"));}while(op!=1);
				break;
				
			case 3:
				
				op1=Integer.parseInt(JOptionPane.showInputDialog(null,"O que voc� quer alterar?\n(1) Nome\n(2) Pre�o\n(3) Quantidade "));
				switch(op1) {
				 case 1: 
					 String produto, novoProduto;
					 produto=(JOptionPane.showInputDialog(null,"Qual produto voc� quer alterar? "));
					 novoProduto=(JOptionPane.showInputDialog(null,"Qual o novo nome? "));
					 
					 if (nomeProduto.contains(produto)){
						System.out.println("ESTOQUE ATUALIZADO!");
						for(int i = 0;i<nomeProduto.size();i++) {
							nomeProduto.get(i);
							nomeProduto.remove(i);
							nomeProduto.add(novoProduto);
							for(i = 0;i<precoProduto.size();i++) {
								
								for( i = 0;i<quantidadeProduto.size();i++) {
									
									System.out.println( "Produto "+nomeProduto.get(i)+"  R$ "+precoProduto.get(i)+" Quant: "+quantidadeProduto.get(i));
						 
								}
							}
						}				
					}else {JOptionPane.showMessageDialog(null, "Produto n�o existe!");}
					break;
				 case 2:
					 String produto1;double novoProduto1;
					 produto1=(JOptionPane.showInputDialog(null,"Qual produto voc� quer alterar? "));
					 novoProduto1=Double.parseDouble(JOptionPane.showInputDialog(null,"Qual o novo pre�o? "));
					 
					 if (nomeProduto.contains(produto1)){
						System.out.println("ESTOQUE ATUALIZADO!");
						for(int i = 0;i<nomeProduto.size();i++) {
							for(i = 0;i<precoProduto.size();i++) {
								precoProduto.get(i);
								precoProduto.remove(i);
								precoProduto.add(novoProduto1);
								for( i = 0;i<quantidadeProduto.size();i++) {
									
									System.out.println( "Produto "+nomeProduto.get(i)+"  R$ "+precoProduto.get(i)+" Quant: "+quantidadeProduto.get(i));
						 
								}
							}
						}				
					}else {JOptionPane.showMessageDialog(null, "Produto n�o existe!");}
					break;
					 
				 case 3:
					 String produto11;int novoProduto11;
					 produto11=(JOptionPane.showInputDialog(null,"Qual produto voc� quer alterar? "));
					 novoProduto11=Integer.parseInt(JOptionPane.showInputDialog(null,"Qual a nova quantidade? "));
					 
					 if (nomeProduto.contains(produto11)){
						System.out.println("ESTOQUE ATUALIZADO!");
						for(int i = 0;i<nomeProduto.size();i++) {
							for(i = 0;i<precoProduto.size();i++) {
								for( i = 0;i<quantidadeProduto.size();i++) {
									quantidadeProduto.get(i);
									quantidadeProduto.remove(i);
									quantidadeProduto.add(novoProduto11);
									
									System.out.println( "Produto "+nomeProduto.get(i)+"  R$ "+precoProduto.get(i)+" Quant: "+quantidadeProduto.get(i));
						 
								}
							}
						}				
					}else {JOptionPane.showMessageDialog(null, "Produto n�o existe!");}
					 op=Integer.parseInt(JOptionPane.showInputDialog(null,"Quer fazer mais altera��o?\n(1) n�o\n(2) sim"));
					 
					break;
					 
			case 4:
				System.out.println( "ESTOQUE!");
				for(int i = 0;i<nomeProduto.size();i++) {
					
					for(i = 0;i<precoProduto.size();i++) {
						
						for( i = 0;i<quantidadeProduto.size();i++) {
							
				System.out.println( "Produto: "+nomeProduto.get(i)+"  R$ "+precoProduto.get(i)+" Quant: "+quantidadeProduto.get(i));
				 
						}
					}
				}			
			
			break;
				
			}default:
				
			}
		}while(op!=0);

	}

}
