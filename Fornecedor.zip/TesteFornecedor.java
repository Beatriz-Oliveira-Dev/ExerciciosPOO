package IncioPOO;

import java.util.Scanner;

public class TesteFornecedor {

	public static void main(String[] args) {
		String nome, genero;
		int idade;
		//entrada de dados do usuario
		try (Scanner ler = new Scanner(System.in)) {
			System.out.println("Qual o seu nome fornecedor?: ");
			nome=ler.nextLine();
			System.out.println("Qual o seu genero?: ");
			genero=ler.nextLine();
			System.out.println("Qual o sua idade: ");
			idade=ler.nextInt();

		//mostrando o credito e a divida e pedindo para ele entrar com a op��o	
			Fornecedor forn1 = new Fornecedor(nome, genero, idade,1000,500);
			System.out.println(nome+" O seu credito incial � de "+forn1.getValorCredito()+" e divida de "+forn1.getValorDivida()+" esses valores"
					+ " n�o s�o alteraveis\nDeseja saber o o seu saldo? Digite\n(1) Para sim\n(2) Para n�o");

			int op = ler.nextInt();
		//tratamento de erro	
			while(op<1 || op>2) {
				System.out.println("Op��o invalida, digite novamente\n(1) sim\n(2) n�o");
				op=ler.nextInt();
			}
		//op��o	
			if(op==1) {
				System.out.println("Seu saldo � de "+forn1.obterSaldo());
				System.out.println("Obrigada por usar nosso sistema!");
 
			}else {System.out.println("Obrigada por usar nosso sistema!");}
			}
			
	}

}
