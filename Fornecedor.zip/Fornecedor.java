package IncioPOO;

public class Fornecedor extends Pessoa {
	private int valorCredito,valorDivida;
	private double saldo;
	
	public Fornecedor(String nome, String genero, int idade, int valorCredito, int valorDivida) {
		super(nome,genero,idade);
		this.valorCredito=valorCredito;
		this.valorDivida=valorDivida;
	}

	public int getValorCredito() {
		return valorCredito;
	}

	public void setValorCredito(int valorCredito) {
		this.valorCredito = valorCredito;
	}

	public int getValorDivida() {
		return valorDivida;
	}

	public void setValorDivida(int valorDivida) {
		this.valorDivida = valorDivida;
	}
	public double obterSaldo() {
		saldo=valorCredito-valorDivida;
		return saldo;
	}
}
