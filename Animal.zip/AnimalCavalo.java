package IncioPOO;

public class AnimalCavalo extends Animal {
	
	public AnimalCavalo(String nome, int idade) {super(nome,idade);}
	
	@Override
	public void somAnimal(String som) {
		som="Irrimmmmmmm....";
		System.out.println("O "+getNome()+"Tem "+getIdade()+" anos"+" faz "+som);
	}

	@Override
	public void acaoAnimal(String acao) {
		acao="Correeee!!!";
		System.out.println("E ele "+acao);
	}

}
