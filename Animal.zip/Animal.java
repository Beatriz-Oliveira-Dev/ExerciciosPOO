package IncioPOO;
/*Crie uma hierarquia de classes conforme abaixo com os seguintes atributos e
comportamentos (observe a tabela), utilize os seus conhecimentos e distribua as
caracter�sticas de forma que tudo o que for comum a todos os animais fique na classe
Animal:*/

//aqui estou criando uma classe abstrata para ver como roda 
public abstract class Animal {
	
	//criando os atributos--> caracteristicas da minha superclass
	private String nome;
	private int idade;
	
	public Animal(String nome, int idade) {this.nome=nome;this.idade=idade;} //<-- meu construtor

	//criar getters and setters
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	//agora os metodos
	abstract public void somAnimal(String som);
	abstract public void acaoAnimal(String acao);

	public void somAnimal() {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
