package IncioPOO;

public class AnimalPreguica extends Animal{

	public AnimalPreguica(String nome, int idade) {super(nome, idade);}

	@Override
	public void somAnimal(String som) {
		som="�hhhhh... �hhhhh";
		System.out.println("A "+getNome()+"Tem "+getIdade()+" anos"+" faz "+som);
		
	}

	@Override
	public void acaoAnimal(String acao) {
		acao="Sobe em arvore";
		System.out.println("E ela "+acao);
		
	}

}
