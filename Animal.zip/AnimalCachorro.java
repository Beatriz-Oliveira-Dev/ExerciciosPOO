package IncioPOO;

public class AnimalCachorro extends Animal {

	public AnimalCachorro(String nome, int idade) {
		super(nome, idade);

	}

	@Override
	public void somAnimal(String som) {
		som="Au...Au..";
		System.out.println("o "+getNome()+"Tem "+getIdade()+" anos"+" faz "+som);
	}

	@Override
	public void acaoAnimal(String acao) {
		acao="Correeee!!!";
		System.out.println("E ele "+acao);
		
	}

}
