package IncioPOO;

import java.util.Scanner;

public class TesteEmpregados {

	public static void main(String[] args) {
		try (Scanner ler = new Scanner(System.in)) {
			//criando as variaveis para a intera��o com o usuario
			String nome, genero;
			int idade,codSetor;
			double salarioBase, imposto;
			//pedindo a entrada para o usuario
			System.out.println("Bem vindo ao auxiliar RH!");
			System.out.println("**********************************");
			System.out.println("Qual o nome do funcionarie?: ");
			nome=ler.nextLine();
			System.out.println("Qual o genero de "+nome+"?: ");
			genero=ler.nextLine();
			System.out.println("E a idade?: ");
			idade=ler.nextInt();
			System.out.println("**********************************");
			System.out.println("Agora vamo calcular o salario de "+nome);
			System.out.println("O Codigo do setor?: ");
			codSetor=ler.nextInt();
			System.out.println("Salario base?: ");
			salarioBase=ler.nextDouble();
			System.out.println("Qual o valor do imposto?: ");
			imposto=ler.nextDouble();
			System.out.println("**********************************");
			//criando o objeto
			Empregados emp1 = new Empregados(nome,genero,idade,codSetor,salarioBase,imposto);
			//calculos e chamando metodos
			emp1.calculoImposto();
			System.out.println(emp1.calculoImposto());
			emp1.calcularSalario();
			System.out.println("Salario de "+nome+" � :"+emp1.calcularSalario());
		}
		
		
		
		
		

	}

}
